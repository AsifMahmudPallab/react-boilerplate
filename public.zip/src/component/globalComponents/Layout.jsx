import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";

export default function Layout(props) {
  return <>{props.children}</>;
}
