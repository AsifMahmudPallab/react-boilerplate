import { BUY_SPICKER } from "./spickerType";

const initState = {
    numbarOfSpicker : 20
}
const spickerReducer = (state = initState, action)=>{
    switch (action.type) {
        case BUY_SPICKER:
            return {...state, numbarOfSpicker: state.numbarOfSpicker - 1 }

    
        default: return state
    }
}

export default spickerReducer;