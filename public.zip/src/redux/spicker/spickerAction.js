import { BUY_SPICKER } from "./spickerType";

const buySpicker = () =>{
    return {
        type: BUY_SPICKER
    }
}
export default buySpicker;