import { combineReducers, createStore } from 'redux';
import clockReducer from './clock/clockReducer';
import spickerReducer from './spicker/spickerReducer';



const rootReducer = combineReducers({
    clock: clockReducer,
    spicker: spickerReducer
})
const store = createStore(rootReducer)

export default store;