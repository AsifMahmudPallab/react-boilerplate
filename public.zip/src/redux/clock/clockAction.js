import { BUY_CLOCK } from "./clockType";

// action creator
const buyClock =()=>{
    return {
        type: BUY_CLOCK
    }
}

export default buyClock;
