// action type
export const BUY_CLOCK = 'BUY_CLOCK';