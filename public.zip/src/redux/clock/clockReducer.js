import { BUY_CLOCK } from "./clockType";
const initState = {
    numbarOfClock : 10
}

const clockReducer = (state = initState, action)=>{
    switch(action.type){
        case BUY_CLOCK: return {
            ...state,
            numbarOfClock : state.numbarOfClock - 1
        }
        default: return state;
    }
}

export default clockReducer;