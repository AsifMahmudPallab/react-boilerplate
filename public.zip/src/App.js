import React, { Component } from "react";
import Layout from "./component/globalComponents/Layout";

class App extends Component {

  
render(){
  return (
    <Layout>
      <div className='text-center'>Hello World</div>
  </Layout>
   );
}
}
export default App  